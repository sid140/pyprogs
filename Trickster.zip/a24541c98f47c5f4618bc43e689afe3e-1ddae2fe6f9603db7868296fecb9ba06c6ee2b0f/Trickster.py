#This is my first Python game 
#Game by Sid 

from random import choice

winner = []
loser = []
loser != winner
print("Trickster".upper())
print("=" * 20)
name = input("Enter your name?:").strip().title()
trick = input("Enter the magic number: ").strip().lower()

if trick == "20":
    print("you won, {}!".format(name))
else:
    print("You lost!")
    loser.append(name)

    print("{},You are now in loser's list".format(name))
    input("Do you want to exit(y/n)?:").strip().lower()
if input() is True:
    exit(0)


